package com.driverL;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DriverLApplication {

	public static void main(String[] args) {
		SpringApplication.run(DriverLApplication.class, args);
	}

}
